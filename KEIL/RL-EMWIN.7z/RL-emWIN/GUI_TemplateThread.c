
#include "cmsis_os.h"                               // CMSIS RTOS header file
#include "GUI.h"

/*----------------------------------------------------------------------------
 *      GUIThread: Thread to run emwin Demos or Templates
 *---------------------------------------------------------------------------*/
 
void GUIThread (void const *argument);              // thread function
osThreadId tid_GUIThread;                           // thread id
osThreadDef (GUIThread, osPriorityIdle, 1, 2048);   // thread object

int Init_GUIThread (void) {

  tid_GUIThread = osThreadCreate (osThread(GUIThread), NULL);
  if (!tid_GUIThread) return(-1);
  
  return(0);
}

void GUIThread (void const *argument) {

  while (1) {
    MainTask();  
    osThreadYield();
  }
}

extern int CreateDADI (void);
/*----------------------------------------------------------------------------
 *      MainTask
 *---------------------------------------------------------------------------*/
void MainTask(void) {
  
  GUI_Init();
	CreateDADI();
  
  
  while(1)  
  {
    GUI_Exec();//GUI_Delay(100);
  }
  
//  GUI_SetBkColor(GUI_RED);
//  GUI_Clear();
//  GUI_Delay(1000);
//  GUI_SetBkColor(GUI_GREEN);
//  GUI_Clear();
//  GUI_Delay(1000);
//  GUI_SetBkColor(GUI_BLUE);
//  GUI_Clear();
//  GUI_Delay(1000);

//  GUI_SetBkColor(GUI_BLACK);
//  GUI_Clear();
//		
//  xSize = LCD_GetXSize();
//  ySize = LCD_GetYSize();

//  GUI_SetFont(&GUI_FontComic24B_1);
//  GUI_SetColor(GUI_CYAN);
//  GUI_DispStringHCenterAt("www.keil.com",   xSize / 2, 20);
//  GUI_SetColor(GUI_DARKBLUE);
//  GUI_DispStringHCenterAt("www.segger.com", xSize / 2, ySize - 40);

//  xPos = xSize / 2;
//  yPos = ySize / 3;
//  GUI_SetColor(GUI_GREEN);
//  GUI_SetTextMode(GUI_TM_REV);
//  GUI_SetFont(GUI_FONT_20F_ASCII);
//  GUI_DispStringHCenterAt("Hello world!", xPos, yPos);
//  GUI_SetFont(GUI_FONT_D24X32);
//  xSize = GUI_GetStringDistX("0000");
//  xPos -= xSize / 2;
//  yPos += 24 + 10;
//  while (1) {
//		GUI_Delay(100);
//    GUI_DispDecAt(i++, xPos, yPos, 4);
//    if (i > 9999) {
//      i=0;
//    }
//  } 
}

